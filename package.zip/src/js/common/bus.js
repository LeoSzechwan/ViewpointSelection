/*
 * @file: bus.js
 * @description: 组件通信
 * @author: Szechwan
 * @version: 1.0.0
 * @date: 2024-08-08
 */
import mitt from 'mitt'

const bus = mitt()

export default bus